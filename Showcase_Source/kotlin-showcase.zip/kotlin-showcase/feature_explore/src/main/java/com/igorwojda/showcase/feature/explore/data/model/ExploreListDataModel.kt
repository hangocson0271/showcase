package com.igorwojda.showcase.feature.explore.data.model

internal data class ExploreListDataModel(
    val album: List<ExploreDataModel>
)
