package com.igorwojda.showcase.feature.explore.domain.enum

internal enum class ExploreDomainImageSize {
    SMALL,
    MEDIUM,
    LARGE,
    EXTRA_LARGE,
    MEGA
}
