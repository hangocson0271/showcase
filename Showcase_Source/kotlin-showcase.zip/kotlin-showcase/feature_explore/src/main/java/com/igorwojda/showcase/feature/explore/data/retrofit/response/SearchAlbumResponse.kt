package com.igorwojda.showcase.feature.explore.data.retrofit.response

import com.igorwojda.showcase.feature.explore.data.model.ExploreSearchResultDataModel

internal data class SearchAlbumResponse(
    val results: ExploreSearchResultDataModel
)
