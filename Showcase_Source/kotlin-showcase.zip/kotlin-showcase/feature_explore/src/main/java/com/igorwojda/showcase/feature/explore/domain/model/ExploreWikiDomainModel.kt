package com.igorwojda.showcase.feature.explore.domain.model

internal data class ExploreWikiDomainModel(
    val published: String,
    val summary: String
)
