package com.igorwojda.showcase.feature.explore.data.model

import com.igorwojda.showcase.feature.explore.data.DataFixtures
import com.igorwojda.showcase.feature.explore.domain.model.ExploreWikiDomainModel
import org.amshove.kluent.shouldBeEqualTo
import org.junit.Test
import org.junit.runner.RunWith
import org.junit.runners.JUnit4

@RunWith(JUnit4::class)
class ExploreWikiDataModelTest {

    @Test
    fun `maps to ExploreWikiDomainModel`() {
        // given
        val published = "published"
        val summary = "summary"
        val cut = DataFixtures.getAlbumWikiDataModel(published, summary)

        // when
        val domainModel = cut.toDomainModel()

        // then
        domainModel shouldBeEqualTo ExploreWikiDomainModel(published, summary)
    }
}
