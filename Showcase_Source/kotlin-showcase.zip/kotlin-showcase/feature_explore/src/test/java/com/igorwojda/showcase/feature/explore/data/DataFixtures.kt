package com.igorwojda.showcase.feature.explore.data

import com.igorwojda.showcase.feature.explore.data.enum.ExploreDataImageSize
import com.igorwojda.showcase.feature.explore.data.model.ExploreDataModel
import com.igorwojda.showcase.feature.explore.data.model.ExploreImageDataModel
import com.igorwojda.showcase.feature.explore.data.model.ExploreWikiDataModel

object DataFixtures {

    internal fun getAlbum(
        mbId: String? = "mbId",
        name: String = "albumName",
        artist: String = "artistName",
        wiki: ExploreWikiDataModel? = getAlbumWikiDataModel(),
        images: List<ExploreImageDataModel>? = listOf(getAlbumImage())
    ): ExploreDataModel = ExploreDataModel(mbId, name, artist, wiki, images)

    internal fun getMinimalAlbum(): ExploreDataModel =
        getAlbum(
            name = "name",
            artist = "artist",
            mbId = null,
            wiki = null,
            images = null
        )

    internal fun getAlbumImage(
        url: String = "url_${ExploreDataImageSize.EXTRA_LARGE}",
        size: ExploreDataImageSize = ExploreDataImageSize.EXTRA_LARGE
    ) = ExploreImageDataModel(url, size)

    internal fun getAlbumWikiDataModel(
        published: String = "published",
        summary: String = "summary"
    ) = ExploreWikiDataModel(published, summary)
}
