package com.igorwojda.showcase.feature.explore.data.enum

import org.junit.Test
import org.junit.runner.RunWith
import org.junit.runners.JUnit4

@RunWith(JUnit4::class)
class ExploreDataImageSizeTest {

    @Test
    fun `maps to ExploreDataImageSize`() {
        // given
        val dataEnums = ExploreDataImageSize.values().filterNot { it == ExploreDataImageSize.UNKNOWN }

        // when
        dataEnums.forEach { it.toDomainEnum() }

        // then
        // no explicit check is required, because test will crash if any of
        // the consts in the enums can't be mapped to a domain enum
    }
}
