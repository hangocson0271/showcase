package com.igorwojda.showcase.feature.explore.data.model

import com.igorwojda.showcase.feature.explore.data.DataFixtures
import com.igorwojda.showcase.feature.explore.data.enum.ExploreDataImageSize
import com.igorwojda.showcase.feature.explore.data.enum.toDomainEnum
import com.igorwojda.showcase.feature.explore.domain.model.ExploreImageDomainModel
import org.amshove.kluent.shouldBeEqualTo
import org.amshove.kluent.shouldThrow
import org.junit.Test
import org.junit.runner.RunWith
import org.junit.runners.JUnit4

@RunWith(JUnit4::class)
class ExploreImageDataModelTest {

    @Test
    fun `maps to AlbumWikiDomainModel`() {
        // given
        val url = "url"
        val size = ExploreDataImageSize.EXTRA_LARGE
        val cut = DataFixtures.getAlbumImage(url, size)

        // when
        val domainModel = cut.toDomainModel()

        // then
        domainModel shouldBeEqualTo ExploreImageDomainModel(url, size.toDomainEnum())
    }

    @Test
    fun `crash when mapping unknown AlbumWikiDomainModel`() {
        // given
        val url = "url"
        val size = ExploreDataImageSize.UNKNOWN
        val cut = DataFixtures.getAlbumImage(url, size)

        // when
        val func = { cut.toDomainModel() }

        // then
        func shouldThrow IllegalArgumentException::class
    }
}
