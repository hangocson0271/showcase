package com.igorwojda.showcase.feature.explore.data.model

import com.igorwojda.showcase.feature.explore.data.DataFixtures
import com.igorwojda.showcase.feature.explore.data.enum.ExploreDataImageSize
import com.igorwojda.showcase.feature.explore.domain.enum.ExploreDomainImageSize
import com.igorwojda.showcase.feature.explore.domain.model.ExploreDomainModel
import org.amshove.kluent.shouldBeEqualTo
import org.junit.Test
import org.junit.runner.RunWith
import org.junit.runners.JUnit4

@RunWith(JUnit4::class)
class ExploreDataModelTest {

    @Test
    fun `data model with full data maps to ExploreDomainModel`() {
        // given
        val cut = DataFixtures.getAlbum()

        // when
        val domainModel = cut.toDomainModel()

        // then
        domainModel shouldBeEqualTo ExploreDomainModel(
            cut.name,
            cut.artist,
            cut.images?.map { it.toDomainModel() } ?: listOf(),
            cut.wiki!!.toDomainModel(),
            cut.mbId!!
        )
    }

    @Test
    fun `data model with missing data maps to ExploreDomainModel`() {
        // given
        val cut = DataFixtures.getMinimalAlbum()

        // when
        val domainModel = cut.toDomainModel()

        // then
        domainModel shouldBeEqualTo ExploreDomainModel(
            name = "name", artist = "artist", images = emptyList(), wiki = null, mbId = null
        )
    }

    @Test
    fun `mapping filters out unknown size`() {
        // given
        val albumDataImages = listOf(ExploreDataImageSize.EXTRA_LARGE, ExploreDataImageSize.UNKNOWN)
            .map { DataFixtures.getAlbumImage(size = it) }
        val cut = DataFixtures.getAlbum(images = albumDataImages)

        // when
        val domainModel = cut.toDomainModel()

        // then
        domainModel.images.single { it.size == ExploreDomainImageSize.EXTRA_LARGE }
    }

    @Test
    fun `mapping filters out blank url`() {
        // given
        val albumDataImages = listOf("", "url")
            .map { DataFixtures.getAlbumImage(url = it) }

        val cut = DataFixtures.getAlbum(images = albumDataImages)

        // when
        val domainModel = cut.toDomainModel()

        // then
        domainModel.images.single { it.url == "url" }
    }
}
