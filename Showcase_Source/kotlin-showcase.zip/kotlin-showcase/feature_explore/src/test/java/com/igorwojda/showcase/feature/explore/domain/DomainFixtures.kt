package com.igorwojda.showcase.feature.explore.domain

import com.igorwojda.showcase.feature.explore.domain.enum.ExploreDomainImageSize
import com.igorwojda.showcase.feature.explore.domain.model.ExploreDomainModel
import com.igorwojda.showcase.feature.explore.domain.model.ExploreImageDomainModel
import com.igorwojda.showcase.feature.explore.domain.model.ExploreWikiDomainModel

object DomainFixtures {

    internal fun getAlbum(
        name: String = "albumName",
        artist: String = "artistName",
        images: List<ExploreImageDomainModel> = listOf(getAlbumImage()),
        wiki: ExploreWikiDomainModel? = getExploreWikiDomainModel(),
        mbId: String? = "mbId"
    ): ExploreDomainModel = ExploreDomainModel(name, artist, images, wiki, mbId)

    internal fun getAlbumImage(
        url: String = "url_${ExploreDomainImageSize.EXTRA_LARGE}",
        size: ExploreDomainImageSize = ExploreDomainImageSize.EXTRA_LARGE
    ) = ExploreImageDomainModel(url, size)

    private fun getExploreWikiDomainModel(
        published: String = "published",
        summary: String = "summary"
    ) = ExploreWikiDomainModel(published, summary)
}
