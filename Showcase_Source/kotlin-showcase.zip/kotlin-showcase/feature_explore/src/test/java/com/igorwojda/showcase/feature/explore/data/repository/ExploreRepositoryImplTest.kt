package com.igorwojda.showcase.feature.explore.data.repository

import com.igorwojda.showcase.feature.explore.data.DataFixtures
import com.igorwojda.showcase.feature.explore.data.model.ExploreListDataModel
import com.igorwojda.showcase.feature.explore.data.model.ExploreSearchResultDataModel
import com.igorwojda.showcase.feature.explore.data.model.toDomainModel
import com.igorwojda.showcase.feature.explore.data.retrofit.response.SearchAlbumResponse
import com.igorwojda.showcase.feature.explore.data.retrofit.service.ExploreRetrofitService
import io.mockk.MockKAnnotations
import io.mockk.coEvery
import io.mockk.impl.annotations.MockK
import kotlinx.coroutines.runBlocking
import org.amshove.kluent.shouldBeEqualTo
import org.junit.Before
import org.junit.Test

class ExploreRepositoryImplTest {

    @MockK
    internal lateinit var mockService: ExploreRetrofitService

    private lateinit var cut: ExploreRepositoryImpl

    @Before
    fun setUp() {
        MockKAnnotations.init(this)

        cut = ExploreRepositoryImpl(mockService)
    }

    @Test
    fun `searchAlbum fetches AlbumInfo and maps to Model`() {
        // given
        val phrase = "phrase"
        coEvery { mockService.searchAlbumAsync(phrase) } returns SearchAlbumResponse(
            ExploreSearchResultDataModel(
                ExploreListDataModel(listOf(DataFixtures.getAlbum()))
            )
        )

        // when
        val result = runBlocking { cut.searchAlbum(phrase) }

        // then
        result shouldBeEqualTo listOf(DataFixtures.getAlbum().toDomainModel())
    }
}
