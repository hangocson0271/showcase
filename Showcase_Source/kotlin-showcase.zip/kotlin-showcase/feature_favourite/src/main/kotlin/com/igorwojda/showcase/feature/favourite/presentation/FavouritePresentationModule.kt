package com.igorwojda.showcase.feature.favourite.presentation

import com.igorwojda.showcase.feature.favourite.MODULE_NAME
import org.kodein.di.Kodein

internal val presentationModule = Kodein.Module("${MODULE_NAME}PresentationModule") { }
