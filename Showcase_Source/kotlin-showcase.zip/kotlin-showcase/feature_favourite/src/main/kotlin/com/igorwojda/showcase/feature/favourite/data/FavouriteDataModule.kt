package com.igorwojda.showcase.feature.favourite.data

import com.igorwojda.showcase.feature.favourite.MODULE_NAME
import org.kodein.di.Kodein

internal val dataModule = Kodein.Module("${MODULE_NAME}DataModule") { }
