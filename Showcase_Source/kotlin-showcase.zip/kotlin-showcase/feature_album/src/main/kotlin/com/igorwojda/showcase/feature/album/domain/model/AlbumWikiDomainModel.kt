package com.igorwojda.showcase.feature.album.domain.model

internal data class AlbumWikiDomainModel(
    val published: String,
    val summary: String
)
