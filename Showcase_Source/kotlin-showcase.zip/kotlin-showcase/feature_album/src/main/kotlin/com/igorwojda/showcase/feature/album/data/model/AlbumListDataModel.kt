package com.igorwojda.showcase.feature.album.data.model

internal data class AlbumListDataModel(
    val album: List<AlbumDataModel>
)
