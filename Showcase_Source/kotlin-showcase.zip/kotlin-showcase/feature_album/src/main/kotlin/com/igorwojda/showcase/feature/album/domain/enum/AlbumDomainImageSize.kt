package com.igorwojda.showcase.feature.album.domain.enum

internal enum class AlbumDomainImageSize {
    SMALL,
    MEDIUM,
    LARGE,
    EXTRA_LARGE,
    MEGA
}
