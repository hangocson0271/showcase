package com.igorwojda.showcase.feature.album.data.retrofit.response

import com.igorwojda.showcase.feature.album.data.model.AlbumDataModel

internal data class GetAlbumInfoResponse(
    val album: AlbumDataModel
)
