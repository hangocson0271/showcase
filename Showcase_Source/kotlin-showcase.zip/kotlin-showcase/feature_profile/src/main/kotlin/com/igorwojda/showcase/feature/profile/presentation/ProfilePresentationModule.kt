package com.igorwojda.showcase.feature.profile.presentation

import com.igorwojda.showcase.feature.profile.MODULE_NAME
import org.kodein.di.Kodein

internal val presentationModule = Kodein.Module("${MODULE_NAME}PresentationModule") { }
