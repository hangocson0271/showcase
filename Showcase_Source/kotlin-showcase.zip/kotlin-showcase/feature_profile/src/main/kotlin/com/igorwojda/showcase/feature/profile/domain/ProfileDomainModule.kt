package com.igorwojda.showcase.feature.profile.domain

import com.igorwojda.showcase.feature.profile.MODULE_NAME
import org.kodein.di.Kodein

internal val domainModule = Kodein.Module("${MODULE_NAME}DomainModule") { }
