package com.igorwojda.showcase.feature.profile.data

import com.igorwojda.showcase.feature.profile.MODULE_NAME
import org.kodein.di.Kodein

internal val dataModule = Kodein.Module("${MODULE_NAME}DataModule") { }
