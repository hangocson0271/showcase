package com.igorwojda.showcase.library.base.presentation.viewmodel

interface BaseViewState
